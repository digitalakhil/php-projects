<h1>Blood Bank Management System</h1>
<p> A simple Blood bank management system in which user can send blood requirement, view upcoming camps, donate blood. This is a self made project for academic purpose</p>

